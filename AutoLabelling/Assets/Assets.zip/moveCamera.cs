﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class moveCamera : MonoBehaviour
{
    List<Vector3> positions = new List<Vector3>();
    int i = 0;

    // { new Vector3(-28.27f, 8.19f, -38.25f), new Vector3(38.5f, 5.4f, 16.13f) };


    // Start is called before the first frame update
    void Start()
    {
        positions.Add(new Vector3(-28.27f, 8.19f, -38.25f));
        positions.Add(new Vector3(38.5f, 5.4f, 16.13f));
    }

    // Update is called once per frame
    void Update()
    {        
        if (Input.GetKeyDown(KeyCode.Space))
        {
            transform.position = positions[i];
            i++;
            if (i == positions.Count)
            {
                i = 0;
            }
        }
           
    }
}
